document.getElementById("titleScreen").style.display = "block";
document.getElementById("gameScreen").style.display = "none";

function startGame() {
    document.getElementById("titleScreen").style.display = "none";
    document.getElementById("gameScreen").style.display = "block";
}